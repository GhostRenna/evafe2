<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Inmobiliario - Registro Gestor</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <header>
        <h1>Registrar Gestor</h1>
        <nav>
            <a href="index.html">Inicio</a>
            <a href="login.html">Iniciar Sesión</a>
        </nav>
    </header>

    <div class="container">
        <h2>Registro como Gestor Inmobiliario</h2>
        <form>
            <div class="form-group">
                <label for="rut">RUT</label>
                <input type="text" id="rut" name="rut" required>
            </div>
            <div class="form-group">
                <label for="nombre">Nombre Completo</label>
                <input type="text" id="nombre" name="nombre" required>
            </div>
            <div class="form-group">
                <label for="fecha-nacimiento">Fecha de Nacimiento</label>
                <input type="date" id="fecha-nacimiento" name="fecha-nacimiento" required>
            </div>
            <div class="form-group">
                <label for="email">Correo Electrónico</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="sexo">Sexo</label>
                <select id="sexo" name="sexo" required>
                    <option value="">Seleccionar</option>
                    <option value="masculino">Masculino</option>
                    <option value="femenino">Femenino</option>
                    <option value="otro">Otro</option>
                </select>
            </div>
            <div class="form-group">
                <label for="telefono">Teléfono Móvil</label>
                <input type="tel" id="telefono" name="telefono" required>
            </div>
            <div class="form-group">
                <label for="certificado">Certificado de Antecedentes</label>
                <input type="file" id="certificado" name="certificado" accept=".pdf" required>
            </div>
            <button type="submit" class="btn">Registrarme</button>
        </form>
    </div>

    <footer>
        <p>&copy; 2025 Portal Inmobiliario. Todos los derechos reservados.</p>
    </footer>
</body>
</html>