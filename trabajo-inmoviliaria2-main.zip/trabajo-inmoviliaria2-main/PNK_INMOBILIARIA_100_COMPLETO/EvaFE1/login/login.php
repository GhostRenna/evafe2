<?php
session_start(); 


$usuarios = [
    ['email' => 'gestor@correo.cl', 'password' => '1234', 'id' => 1, 'nombre' => 'Juan Gestor', 'rol' => 'gestor'],
    ['email' => 'propietario@correo.cl', 'password' => 'abcd', 'id' => 2, 'nombre' => 'Ana Propietaria', 'rol' => 'propietario']
];


$email = $_POST['email'];
$password = $_POST['password'];


$usuarioEncontrado = null;
foreach ($usuarios as $usuario) {
    if ($usuario['email'] === $email && $usuario['password'] === $password) {
        $usuarioEncontrado = $usuario;
        break;
    }
}

if ($usuarioEncontrado) {

    $_SESSION['id'] = $usuarioEncontrado['id'];
    $_SESSION['nombre'] = $usuarioEncontrado['nombre'];
    $_SESSION['rol'] = $usuarioEncontrado['rol'];

  
    header("Location: dashboard.php");
    exit();
} else {

    echo "<p>Usuario o contraseña incorrectos. <a href='login.html'>Volver</a></p>";
}
?>
