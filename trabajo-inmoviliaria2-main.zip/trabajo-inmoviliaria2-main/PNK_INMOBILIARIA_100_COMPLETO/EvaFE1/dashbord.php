<?php
session_start();


if (!isset($_SESSION['id'])) {
    header("Location: login.html"); 
    exit();
}

echo "<h1>Bienvenido, " . $_SESSION['nombre'] . " (" . $_SESSION['rol'] . ")</h1>";
echo "<p>Tu ID de usuario es: " . $_SESSION['id'] . "</p>";
echo "<a href='logout.php'>Cerrar sesión</a>";
?>
