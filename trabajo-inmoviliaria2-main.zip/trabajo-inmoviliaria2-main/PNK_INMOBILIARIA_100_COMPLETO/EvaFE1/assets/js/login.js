document.getElementById("loginForm").addEventListener("submit", function(event) {
    const correo = document.getElementById("correo").value;
    const password = document.getElementById("password").value;
    const correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;

    if (correo === "" || password === "") {
        alert("Por favor, completa todos los campos.");
        event.preventDefault();
    }

    if (!correoRegex.test(correo)) {
        alert("Por favor, ingresa un correo electrónico válido.");
        event.preventDefault();
    }   

    if (!passwordRegex.test(password)) {
        alert("La contraseña debe tener al menos 8 caracteres, una letra mayúscula, una letra minúscula y un número.");
        event.preventDefault();
    }
});